# Ex.No: 10  Implementation of 2D/3D game -------------------
### DATE:                                                                            
### REGISTER NUMBER : 
### AIM: 
To develop a game -------------------------in Unity 
### Algorithm:
```
1.
```  
### Program:
```
```
### Output:

### Result:
Thus the game was developed using Unity and adopted _-----------AI technology.
