# Ex.No: 1  Installation of Unity for Game Development
### DATE:                                                                            
### REGISTER NUMBER : 
### AIM: 
To install Unity2022.3.57f1 or higher version for Game Development.
### Procedure:
1. Goto website https://unity.com/releases/editor/archive or https://unity.com/download  and choose the corresponding Unity Hub and download it.
2. Create a personal login and choose the plan
   
   ![image](https://github.com/user-attachments/assets/f6a2db46-908f-4a91-b63d-794af5cb35d8)
   
4. Open the unity Hub and choose install button.
   
   ![image](https://github.com/user-attachments/assets/ecbd5e46-cd02-4966-a470-4833e05c2574)
   
6. Choose Unity install editor and specify the location
   
 ![image](https://github.com/user-attachments/assets/d9e882d1-a73e-4704-a554-2ea4eb1964c7)

8.  Add modules Microsoft Visual studio community 2022 ,documentation and continue
9.  After unity hub editor and  Visual studio community 2022 installation proceeds
   
   ![image](https://github.com/user-attachments/assets/4425bc37-99c3-4fc6-b887-da5366ae9860)
   
9.Now install shows like 

![image](https://github.com/user-attachments/assets/7e1dd5c5-4398-4c10-89cd-5f0442f49c59)

10.Select projects and create new 2D or 3D project and verify all are working

![image](https://github.com/user-attachments/assets/c902763e-4ba5-42b7-8251-a74db9ba5a42)


### Result:
Thus the unity installation was completed sucessfully.


